'use server';
import { redirect } from 'next/navigation'; import { createClient } from '@/lib/supabase/server'; import { discoverySchema } from '@/lib/validation/discovery';
export async function saveDiscovery(formData:FormData){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect('/login');
 const parsed=discoverySchema.safeParse({debugSessionId:formData.get('debugSessionId'),type:formData.get('type'),title:formData.get('title'),description:formData.get('description')||undefined,confidence:formData.get('confidence')}); if(!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? 'Invalid discovery.');
 const d=parsed.data; const {data:session,error:sErr}=await supabase.from('debug_sessions').select('id,workspace_id,situation,occurred_at').eq('id',d.debugSessionId).single(); if(sErr||!session) throw new Error('Debug session unavailable.');
 const {data:component,error:cErr}=await supabase.from('components').insert({workspace_id:session.workspace_id,type:d.type,title:d.title,description:d.description??null,status:'candidate',confidence:d.confidence,first_observed_at:session.occurred_at??new Date().toISOString(),last_observed_at:session.occurred_at??new Date().toISOString()}).select('id').single(); if(cErr) throw new Error(cErr.message);
 const {data:obs,error:oErr}=await supabase.from('observations').insert({workspace_id:session.workspace_id,debug_session_id:session.id,observation_type:'pattern',content:d.description||d.title,occurred_at:session.occurred_at}).select('id').single(); if(oErr) throw new Error(oErr.message);
 const {error:eErr}=await supabase.from('component_evidence').insert({component_id:component.id,observation_id:obs.id,strength:d.confidence==='high'?'strong':d.confidence==='medium'?'moderate':'weak'}); if(eErr) throw new Error(eErr.message);
 await supabase.from('debug_sessions').update({status:'completed'}).eq('id',session.id); redirect(`/debug/${session.id}`);
}
